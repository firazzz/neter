!(function (e) {
  var n = (function () {
      try {
        return !!Symbol.iterator
      } catch (e) {
        return !1
      }
    })(),
    t = function (e) {
      var t = {
        next: function () {
          var n = e.shift()
          return { done: void 0 === n, value: n }
        },
      }
      return (
        n &&
          (t[Symbol.iterator] = function () {
            return t
          }),
        t
      )
    },
    r = function (e) {
      return encodeURIComponent(e).replace(/%20/g, '+')
    },
    o = function (e) {
      return decodeURIComponent(String(e).replace(/\+/g, ' '))
    }
  ;(function () {
    try {
      var n = e.URLSearchParams
      return (
        'a=1' === new n('?a=1').toString() &&
        'function' == typeof n.prototype.set
      )
    } catch (t) {
      return !1
    }
  })() ||
    (function () {
      var o = function (e) {
          Object.defineProperty(this, '_entries', { writable: !0, value: {} })
          var n = typeof e
          if ('undefined' === n);
          else if ('string' === n) '' !== e && this._fromString(e)
          else if (e instanceof o) {
            var t = this
            e.forEach(function (e, n) {
              t.append(n, e)
            })
          } else {
            if (null === e || 'object' !== n)
              throw new TypeError(
                "Unsupported input's type for URLSearchParams",
              )
            if ('[object Array]' === Object.prototype.toString.call(e))
              for (var r = 0; r < e.length; r++) {
                var i = e[r]
                if (
                  '[object Array]' !== Object.prototype.toString.call(i) &&
                  2 === i.length
                )
                  throw new TypeError(
                    'Expected [string, any] as entry at index ' +
                      r +
                      " of URLSearchParams's input",
                  )
                this.append(i[0], i[1])
              }
            else for (var a in e) e.hasOwnProperty(a) && this.append(a, e[a])
          }
        },
        i = o.prototype
      ;(i.append = function (e, n) {
        e in this._entries
          ? this._entries[e].push(String(n))
          : (this._entries[e] = [String(n)])
      }),
        (i.delete = function (e) {
          delete this._entries[e]
        }),
        (i.get = function (e) {
          return e in this._entries ? this._entries[e][0] : null
        }),
        (i.getAll = function (e) {
          return e in this._entries ? this._entries[e].slice(0) : []
        }),
        (i.has = function (e) {
          return e in this._entries
        }),
        (i.set = function (e, n) {
          this._entries[e] = [String(n)]
        }),
        (i.forEach = function (e, n) {
          var t
          for (var r in this._entries)
            if (this._entries.hasOwnProperty(r)) {
              t = this._entries[r]
              for (var o = 0; o < t.length; o++) e.call(n, t[o], r, this)
            }
        }),
        (i.keys = function () {
          var e = []
          return (
            this.forEach(function (n, t) {
              e.push(t)
            }),
            t(e)
          )
        }),
        (i.values = function () {
          var e = []
          return (
            this.forEach(function (n) {
              e.push(n)
            }),
            t(e)
          )
        }),
        (i.entries = function () {
          var e = []
          return (
            this.forEach(function (n, t) {
              e.push([t, n])
            }),
            t(e)
          )
        }),
        n && (i[Symbol.iterator] = i.entries),
        (i.toString = function () {
          var e = []
          return (
            this.forEach(function (n, t) {
              e.push(r(t) + '=' + r(n))
            }),
            e.join('&')
          )
        }),
        (e.URLSearchParams = o)
    })()
  var i = e.URLSearchParams.prototype
  'function' != typeof i.sort &&
    (i.sort = function () {
      var e = this,
        n = []
      this.forEach(function (t, r) {
        n.push([r, t]), e._entries || e.delete(r)
      }),
        n.sort(function (e, n) {
          return e[0] < n[0] ? -1 : e[0] > n[0] ? 1 : 0
        }),
        e._entries && (e._entries = {})
      for (var t = 0; t < n.length; t++) this.append(n[t][0], n[t][1])
    }),
    'function' != typeof i._fromString &&
      Object.defineProperty(i, '_fromString', {
        enumerable: !1,
        configurable: !1,
        writable: !1,
        value: function (e) {
          if (this._entries) this._entries = {}
          else {
            var n = []
            this.forEach(function (e, t) {
              n.push(t)
            })
            for (var t = 0; t < n.length; t++) this.delete(n[t])
          }
          var r,
            i = (e = e.replace(/^\?/, '')).split('&')
          for (t = 0; t < i.length; t++)
            (r = i[t].split('=')),
              this.append(o(r[0]), r.length > 1 ? o(r[1]) : '')
        },
      })
})(
  'undefined' != typeof global
    ? global
    : 'undefined' != typeof window
    ? window
    : 'undefined' != typeof self
    ? self
    : this,
),
  (function (e) {
    var n, t, r
    if (
      ((function () {
        try {
          var n = new e.URL('b', 'http://a')
          return (
            (n.pathname = 'c%20d'),
            'http://a/c%20d' === n.href && n.searchParams
          )
        } catch (t) {
          return !1
        }
      })() ||
        ((n = e.URL),
        (r = (t = function (n, t) {
          'string' != typeof n && (n = String(n))
          var r,
            o = document
          if (t && (void 0 === e.location || t !== e.location.href)) {
            ;((r = (o = document.implementation.createHTMLDocument(
              '',
            )).createElement('base')).href = t),
              o.head.appendChild(r)
            try {
              if (0 !== r.href.indexOf(t)) throw new Error(r.href)
            } catch (l) {
              throw new Error('URL unable to set base ' + t + ' due to ' + l)
            }
          }
          var i = o.createElement('a')
          if (
            ((i.href = n),
            r && (o.body.appendChild(i), (i.href = i.href)),
            ':' === i.protocol || !/:/.test(i.href))
          )
            throw new TypeError('Invalid URL')
          Object.defineProperty(this, '_anchorElement', { value: i })
          var a = new e.URLSearchParams(this.search),
            c = !0,
            u = !0,
            f = this
          ;['append', 'delete', 'set'].forEach(function (e) {
            var n = a[e]
            a[e] = function () {
              n.apply(a, arguments),
                c && ((u = !1), (f.search = a.toString()), (u = !0))
            }
          }),
            Object.defineProperty(this, 'searchParams', {
              value: a,
              enumerable: !0,
            })
          var s = void 0
          Object.defineProperty(this, '_updateSearchParams', {
            enumerable: !1,
            configurable: !1,
            writable: !1,
            value: function () {
              this.search !== s &&
                ((s = this.search),
                u &&
                  ((c = !1),
                  this.searchParams._fromString(this.search),
                  (c = !0)))
            },
          })
        }).prototype),
        ['hash', 'host', 'hostname', 'port', 'protocol'].forEach(function (e) {
          !(function (e) {
            Object.defineProperty(r, e, {
              get: function () {
                return this._anchorElement[e]
              },
              set: function (n) {
                this._anchorElement[e] = n
              },
              enumerable: !0,
            })
          })(e)
        }),
        Object.defineProperty(r, 'search', {
          get: function () {
            return this._anchorElement.search
          },
          set: function (e) {
            ;(this._anchorElement.search = e), this._updateSearchParams()
          },
          enumerable: !0,
        }),
        Object.defineProperties(r, {
          toString: {
            get: function () {
              var e = this
              return function () {
                return e.href
              }
            },
          },
          href: {
            get: function () {
              return this._anchorElement.href.replace(/\?$/, '')
            },
            set: function (e) {
              ;(this._anchorElement.href = e), this._updateSearchParams()
            },
            enumerable: !0,
          },
          pathname: {
            get: function () {
              return this._anchorElement.pathname.replace(/(^\/?)/, '/')
            },
            set: function (e) {
              this._anchorElement.pathname = e
            },
            enumerable: !0,
          },
          origin: {
            get: function () {
              return (
                this._anchorElement.protocol +
                '//' +
                this._anchorElement.hostname +
                (this._anchorElement.port !=
                  { 'http:': 80, 'https:': 443, 'ftp:': 21 }[
                    this._anchorElement.protocol
                  ] && '' !== this._anchorElement.port
                  ? ':' + this._anchorElement.port
                  : '')
              )
            },
            enumerable: !0,
          },
          password: {
            get: function () {
              return ''
            },
            set: function (e) {},
            enumerable: !0,
          },
          username: {
            get: function () {
              return ''
            },
            set: function (e) {},
            enumerable: !0,
          },
        }),
        (t.createObjectURL = function (e) {
          return n.createObjectURL.apply(n, arguments)
        }),
        (t.revokeObjectURL = function (e) {
          return n.revokeObjectURL.apply(n, arguments)
        }),
        (e.URL = t)),
      void 0 !== e.location && !('origin' in e.location))
    ) {
      var o = function () {
        return (
          e.location.protocol +
          '//' +
          e.location.hostname +
          (e.location.port ? ':' + e.location.port : '')
        )
      }
      try {
        Object.defineProperty(e.location, 'origin', { get: o, enumerable: !0 })
      } catch (i) {
        setInterval(function () {
          e.location.origin = o()
        }, 100)
      }
    }
  })(
    'undefined' != typeof global
      ? global
      : 'undefined' != typeof window
      ? window
      : 'undefined' != typeof self
      ? self
      : this,
  ),
  (function (e) {
    'object' == typeof exports && 'undefined' != typeof module
      ? (module.exports = e())
      : 'function' == typeof define && define.amd
      ? define([], e)
      : (('undefined' != typeof window
          ? window
          : 'undefined' != typeof global
          ? global
          : 'undefined' != typeof self
          ? self
          : this
        ).localforage = e())
  })(function () {
    return (function e(n, t, r) {
      function o(a, c) {
        if (!t[a]) {
          if (!n[a]) {
            var u = 'function' == typeof require && require
            if (!c && u) return u(a, !0)
            if (i) return i(a, !0)
            var f = new Error("Cannot find module '" + a + "'")
            throw ((f.code = 'MODULE_NOT_FOUND'), f)
          }
          var s = (t[a] = { exports: {} })
          n[a][0].call(
            s.exports,
            function (e) {
              return o(n[a][1][e] || e)
            },
            s,
            s.exports,
            e,
            n,
            t,
            r,
          )
        }
        return t[a].exports
      }
      for (
        var i = 'function' == typeof require && require, a = 0;
        a < r.length;
        a++
      )
        o(r[a])
      return o
    })(
      {
        1: [
          function (e, n, t) {
            'use strict'
            function r(e, n) {
              ;(e = e || []), (n = n || {})
              try {
                return new Blob(e, n)
              } catch (o) {
                if ('TypeError' !== o.name) throw o
                for (
                  var t = new ('undefined' != typeof BlobBuilder
                      ? BlobBuilder
                      : 'undefined' != typeof MSBlobBuilder
                      ? MSBlobBuilder
                      : 'undefined' != typeof MozBlobBuilder
                      ? MozBlobBuilder
                      : WebKitBlobBuilder)(),
                    r = 0;
                  r < e.length;
                  r += 1
                )
                  t.append(e[r])
                return t.getBlob(n.type)
              }
            }
            function o(e, n) {
              n &&
                e.then(
                  function (e) {
                    n(null, e)
                  },
                  function (e) {
                    n(e)
                  },
                )
            }
            function i(e, n, t) {
              'function' == typeof n && e.then(n),
                'function' == typeof t && e.catch(t)
            }
            function a(e) {
              return (
                'string' != typeof e &&
                  (console.warn(e + ' used as a key, but it is not a string.'),
                  (e = String(e))),
                e
              )
            }
            function c() {
              if (
                arguments.length &&
                'function' == typeof arguments[arguments.length - 1]
              )
                return arguments[arguments.length - 1]
            }
            function u(e) {
              for (
                var n = e.length,
                  t = new ArrayBuffer(n),
                  r = new Uint8Array(t),
                  o = 0;
                o < n;
                o++
              )
                r[o] = e.charCodeAt(o)
              return t
            }
            function f(e) {
              var n = L[e.name],
                t = {}
              ;(t.promise = new x(function (e, n) {
                ;(t.resolve = e), (t.reject = n)
              })),
                n.deferredOperations.push(t),
                (n.dbReady = n.dbReady
                  ? n.dbReady.then(function () {
                      return t.promise
                    })
                  : t.promise)
            }
            function s(e) {
              var n = L[e.name].deferredOperations.pop()
              if (n) return n.resolve(), n.promise
            }
            function l(e, n) {
              var t = L[e.name].deferredOperations.pop()
              if (t) return t.reject(n), t.promise
            }
            function d(e, n) {
              return new x(function (t, r) {
                if (
                  ((L[e.name] = L[e.name] || {
                    forages: [],
                    db: null,
                    dbReady: null,
                    deferredOperations: [],
                  }),
                  e.db)
                ) {
                  if (!n) return t(e.db)
                  f(e), e.db.close()
                }
                var o = [e.name]
                n && o.push(e.version)
                var i = D.open.apply(D, o)
                n &&
                  (i.onupgradeneeded = function (n) {
                    var t = i.result
                    try {
                      t.createObjectStore(e.storeName),
                        n.oldVersion <= 1 && t.createObjectStore(k)
                    } catch (t) {
                      if ('ConstraintError' !== t.name) throw t
                      console.warn(
                        'The database "' +
                          e.name +
                          '" has been upgraded from version ' +
                          n.oldVersion +
                          ' to version ' +
                          n.newVersion +
                          ', but the storage "' +
                          e.storeName +
                          '" already exists.',
                      )
                    }
                  }),
                  (i.onerror = function (e) {
                    e.preventDefault(), r(i.error)
                  }),
                  (i.onsuccess = function () {
                    t(i.result), s(e)
                  })
              })
            }
            function h(e) {
              return d(e, !1)
            }
            function v(e) {
              return d(e, !0)
            }
            function p(e, n) {
              if (!e.db) return !0
              var t = !e.db.objectStoreNames.contains(e.storeName),
                r = e.version > e.db.version
              if (
                (e.version < e.db.version &&
                  (e.version !== n &&
                    console.warn(
                      'The database "' +
                        e.name +
                        '" can\'t be downgraded from version ' +
                        e.db.version +
                        ' to version ' +
                        e.version +
                        '.',
                    ),
                  (e.version = e.db.version)),
                r || t)
              ) {
                if (t) {
                  var o = e.db.version + 1
                  o > e.version && (e.version = o)
                }
                return !0
              }
              return !1
            }
            function y(e) {
              return r([u(atob(e.data))], { type: e.type })
            }
            function b(e) {
              return e && e.__local_forage_encoded_blob
            }
            function m(e) {
              var n = this,
                t = n._initReady().then(function () {
                  var e = L[n._dbInfo.name]
                  if (e && e.dbReady) return e.dbReady
                })
              return i(t, e, e), t
            }
            function g(e, n, t, r) {
              void 0 === r && (r = 1)
              try {
                var o = e.db.transaction(e.storeName, n)
                t(null, o)
              } catch (o) {
                if (
                  r > 0 &&
                  (!e.db ||
                    'InvalidStateError' === o.name ||
                    'NotFoundError' === o.name)
                )
                  return x
                    .resolve()
                    .then(function () {
                      if (
                        !e.db ||
                        ('NotFoundError' === o.name &&
                          !e.db.objectStoreNames.contains(e.storeName) &&
                          e.version <= e.db.version)
                      )
                        return e.db && (e.version = e.db.version + 1), v(e)
                    })
                    .then(function () {
                      return (function (e) {
                        f(e)
                        for (
                          var n = L[e.name], t = n.forages, r = 0;
                          r < t.length;
                          r++
                        ) {
                          var o = t[r]
                          o._dbInfo.db &&
                            (o._dbInfo.db.close(), (o._dbInfo.db = null))
                        }
                        return (
                          (e.db = null),
                          h(e)
                            .then(function (n) {
                              return (e.db = n), p(e) ? v(e) : n
                            })
                            .then(function (r) {
                              e.db = n.db = r
                              for (var o = 0; o < t.length; o++)
                                t[o]._dbInfo.db = r
                            })
                            .catch(function (n) {
                              throw (l(e, n), n)
                            })
                        )
                      })(e).then(function () {
                        g(e, n, t, r - 1)
                      })
                    })
                    .catch(t)
                t(o)
              }
            }
            function _(e) {
              var n,
                t,
                r,
                o,
                i,
                a = 0.75 * e.length,
                c = e.length,
                u = 0
              '=' === e[e.length - 1] && (a--, '=' === e[e.length - 2] && a--)
              var f = new ArrayBuffer(a),
                s = new Uint8Array(f)
              for (n = 0; n < c; n += 4)
                (t = z.indexOf(e[n])),
                  (r = z.indexOf(e[n + 1])),
                  (o = z.indexOf(e[n + 2])),
                  (i = z.indexOf(e[n + 3])),
                  (s[u++] = (t << 2) | (r >> 4)),
                  (s[u++] = ((15 & r) << 4) | (o >> 2)),
                  (s[u++] = ((3 & o) << 6) | (63 & i))
              return f
            }
            function S(e) {
              var n,
                t = new Uint8Array(e),
                r = ''
              for (n = 0; n < t.length; n += 3)
                (r += z[t[n] >> 2]),
                  (r += z[((3 & t[n]) << 4) | (t[n + 1] >> 4)]),
                  (r += z[((15 & t[n + 1]) << 2) | (t[n + 2] >> 6)]),
                  (r += z[63 & t[n + 2]])
              return (
                t.length % 3 == 2
                  ? (r = r.substring(0, r.length - 1) + '=')
                  : t.length % 3 == 1 &&
                    (r = r.substring(0, r.length - 2) + '=='),
                r
              )
            }
            function w(e, n, t, r) {
              e.executeSql(
                'CREATE TABLE IF NOT EXISTS ' +
                  n.storeName +
                  ' (id INTEGER PRIMARY KEY, key unique, value)',
                [],
                t,
                r,
              )
            }
            function I(e, n, t, r, o, i) {
              e.executeSql(
                t,
                r,
                o,
                function (e, a) {
                  a.code === a.SYNTAX_ERR
                    ? e.executeSql(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name = ?",
                        [n.storeName],
                        function (e, c) {
                          c.rows.length
                            ? i(e, a)
                            : w(
                                e,
                                n,
                                function () {
                                  e.executeSql(t, r, o, i)
                                },
                                i,
                              )
                        },
                        i,
                      )
                    : i(e, a)
                },
                i,
              )
            }
            function E(e, n, t, r) {
              var i = this
              e = a(e)
              var c = new x(function (o, a) {
                i.ready()
                  .then(function () {
                    void 0 === n && (n = null)
                    var c = n,
                      u = i._dbInfo
                    u.serializer.serialize(n, function (n, f) {
                      f
                        ? a(f)
                        : u.db.transaction(
                            function (t) {
                              I(
                                t,
                                u,
                                'INSERT OR REPLACE INTO ' +
                                  u.storeName +
                                  ' (key, value) VALUES (?, ?)',
                                [e, n],
                                function () {
                                  o(c)
                                },
                                function (e, n) {
                                  a(n)
                                },
                              )
                            },
                            function (n) {
                              if (n.code === n.QUOTA_ERR) {
                                if (r > 0)
                                  return void o(E.apply(i, [e, c, t, r - 1]))
                                a(n)
                              }
                            },
                          )
                    })
                  })
                  .catch(a)
              })
              return o(c, t), c
            }
            function N(e) {
              return new x(function (n, t) {
                e.transaction(
                  function (r) {
                    r.executeSql(
                      "SELECT name FROM sqlite_master WHERE type='table' AND name <> '__WebKitDatabaseInfoTable__'",
                      [],
                      function (t, r) {
                        for (var o = [], i = 0; i < r.rows.length; i++)
                          o.push(r.rows.item(i).name)
                        n({ db: e, storeNames: o })
                      },
                      function (e, n) {
                        t(n)
                      },
                    )
                  },
                  function (e) {
                    t(e)
                  },
                )
              })
            }
            function O(e, n) {
              var t = e.name + '/'
              return e.storeName !== n.storeName && (t += e.storeName + '/'), t
            }
            function R(e, n) {
              e[n] = function () {
                var t = arguments
                return e.ready().then(function () {
                  return e[n].apply(e, t)
                })
              }
            }
            function j() {
              for (var e = 1; e < arguments.length; e++) {
                var n = arguments[e]
                if (n)
                  for (var t in n)
                    n.hasOwnProperty(t) &&
                      (arguments[0][t] = ce(n[t]) ? n[t].slice() : n[t])
              }
              return arguments[0]
            }
            var A =
                'function' == typeof Symbol &&
                'symbol' == typeof Symbol.iterator
                  ? function (e) {
                      return typeof e
                    }
                  : function (e) {
                      return e &&
                        'function' == typeof Symbol &&
                        e.constructor === Symbol &&
                        e !== Symbol.prototype
                        ? 'symbol'
                        : typeof e
                    },
              D = (function () {
                try {
                  if ('undefined' != typeof indexedDB) return indexedDB
                  if ('undefined' != typeof webkitIndexedDB)
                    return webkitIndexedDB
                  if ('undefined' != typeof mozIndexedDB) return mozIndexedDB
                  if ('undefined' != typeof OIndexedDB) return OIndexedDB
                  if ('undefined' != typeof msIndexedDB) return msIndexedDB
                } catch (e) {
                  return
                }
              })()
            'undefined' == typeof Promise && e('lie/polyfill')
            var x = Promise,
              k = 'local-forage-detect-blob-support',
              B = void 0,
              L = {},
              P = Object.prototype.toString,
              T = 'readonly',
              C = 'readwrite',
              U = {
                _driver: 'asyncStorage',
                _initStorage: function (e) {
                  function n() {
                    return x.resolve()
                  }
                  var t = this,
                    r = { db: null }
                  if (e) for (var o in e) r[o] = e[o]
                  var i = L[r.name]
                  i ||
                    (L[r.name] = i = {
                      forages: [],
                      db: null,
                      dbReady: null,
                      deferredOperations: [],
                    }),
                    i.forages.push(t),
                    t._initReady || ((t._initReady = t.ready), (t.ready = m))
                  for (var a = [], c = 0; c < i.forages.length; c++) {
                    var u = i.forages[c]
                    u !== t && a.push(u._initReady().catch(n))
                  }
                  var f = i.forages.slice(0)
                  return x
                    .all(a)
                    .then(function () {
                      return (r.db = i.db), h(r)
                    })
                    .then(function (e) {
                      return (
                        (r.db = e), p(r, t._defaultConfig.version) ? v(r) : e
                      )
                    })
                    .then(function (e) {
                      ;(r.db = i.db = e), (t._dbInfo = r)
                      for (var n = 0; n < f.length; n++) {
                        var o = f[n]
                        o !== t &&
                          ((o._dbInfo.db = r.db),
                          (o._dbInfo.version = r.version))
                      }
                    })
                },
                _support: (function () {
                  try {
                    if (!D) return !1
                    var e =
                        'undefined' != typeof openDatabase &&
                        /(Safari|iPhone|iPad|iPod)/.test(navigator.userAgent) &&
                        !/Chrome/.test(navigator.userAgent) &&
                        !/BlackBerry/.test(navigator.platform),
                      n =
                        'function' == typeof fetch &&
                        -1 !== fetch.toString().indexOf('[native code')
                    return (
                      (!e || n) &&
                      'undefined' != typeof indexedDB &&
                      'undefined' != typeof IDBKeyRange
                    )
                  } catch (e) {
                    return !1
                  }
                })(),
                iterate: function (e, n) {
                  var t = this,
                    r = new x(function (n, r) {
                      t.ready()
                        .then(function () {
                          g(t._dbInfo, T, function (o, i) {
                            if (o) return r(o)
                            try {
                              var a = i
                                  .objectStore(t._dbInfo.storeName)
                                  .openCursor(),
                                c = 1
                              ;(a.onsuccess = function () {
                                var t = a.result
                                if (t) {
                                  var r = t.value
                                  b(r) && (r = y(r))
                                  var o = e(r, t.key, c++)
                                  void 0 !== o ? n(o) : t.continue()
                                } else n()
                              }),
                                (a.onerror = function () {
                                  r(a.error)
                                })
                            } catch (e) {
                              r(e)
                            }
                          })
                        })
                        .catch(r)
                    })
                  return o(r, n), r
                },
                getItem: function (e, n) {
                  var t = this
                  e = a(e)
                  var r = new x(function (n, r) {
                    t.ready()
                      .then(function () {
                        g(t._dbInfo, T, function (o, i) {
                          if (o) return r(o)
                          try {
                            var a = i.objectStore(t._dbInfo.storeName).get(e)
                            ;(a.onsuccess = function () {
                              var e = a.result
                              void 0 === e && (e = null),
                                b(e) && (e = y(e)),
                                n(e)
                            }),
                              (a.onerror = function () {
                                r(a.error)
                              })
                          } catch (e) {
                            r(e)
                          }
                        })
                      })
                      .catch(r)
                  })
                  return o(r, n), r
                },
                setItem: function (e, n, t) {
                  var i = this
                  e = a(e)
                  var c = new x(function (t, o) {
                    var a
                    i.ready()
                      .then(function () {
                        return (
                          (a = i._dbInfo),
                          '[object Blob]' === P.call(n)
                            ? (function (e) {
                                return 'boolean' == typeof B
                                  ? x.resolve(B)
                                  : (function (e) {
                                      return new x(function (n) {
                                        var t = e.transaction(k, C),
                                          o = r([''])
                                        t.objectStore(k).put(o, 'key'),
                                          (t.onabort = function (e) {
                                            e.preventDefault(),
                                              e.stopPropagation(),
                                              n(!1)
                                          }),
                                          (t.oncomplete = function () {
                                            var e = navigator.userAgent.match(
                                                /Chrome\/(\d+)/,
                                              ),
                                              t = navigator.userAgent.match(
                                                /Edge\//,
                                              )
                                            n(
                                              t ||
                                                !e ||
                                                parseInt(e[1], 10) >= 43,
                                            )
                                          })
                                      }).catch(function () {
                                        return !1
                                      })
                                    })(e).then(function (e) {
                                      return (B = e)
                                    })
                              })(a.db).then(function (e) {
                                return e
                                  ? n
                                  : (function (e) {
                                      return new x(function (n, t) {
                                        var r = new FileReader()
                                        ;(r.onerror = t),
                                          (r.onloadend = function (t) {
                                            var r = btoa(t.target.result || '')
                                            n({
                                              __local_forage_encoded_blob: !0,
                                              data: r,
                                              type: e.type,
                                            })
                                          }),
                                          r.readAsBinaryString(e)
                                      })
                                    })(n)
                              })
                            : n
                        )
                      })
                      .then(function (n) {
                        g(i._dbInfo, C, function (r, a) {
                          if (r) return o(r)
                          try {
                            var c = a.objectStore(i._dbInfo.storeName)
                            null === n && (n = void 0)
                            var u = c.put(n, e)
                            ;(a.oncomplete = function () {
                              void 0 === n && (n = null), t(n)
                            }),
                              (a.onabort = a.onerror = function () {
                                o(u.error ? u.error : u.transaction.error)
                              })
                          } catch (e) {
                            o(e)
                          }
                        })
                      })
                      .catch(o)
                  })
                  return o(c, t), c
                },
                removeItem: function (e, n) {
                  var t = this
                  e = a(e)
                  var r = new x(function (n, r) {
                    t.ready()
                      .then(function () {
                        g(t._dbInfo, C, function (o, i) {
                          if (o) return r(o)
                          try {
                            var a = i.objectStore(t._dbInfo.storeName).delete(e)
                            ;(i.oncomplete = function () {
                              n()
                            }),
                              (i.onerror = function () {
                                r(a.error)
                              }),
                              (i.onabort = function () {
                                r(a.error ? a.error : a.transaction.error)
                              })
                          } catch (e) {
                            r(e)
                          }
                        })
                      })
                      .catch(r)
                  })
                  return o(r, n), r
                },
                clear: function (e) {
                  var n = this,
                    t = new x(function (e, t) {
                      n.ready()
                        .then(function () {
                          g(n._dbInfo, C, function (r, o) {
                            if (r) return t(r)
                            try {
                              var i = o.objectStore(n._dbInfo.storeName).clear()
                              ;(o.oncomplete = function () {
                                e()
                              }),
                                (o.onabort = o.onerror = function () {
                                  t(i.error ? i.error : i.transaction.error)
                                })
                            } catch (e) {
                              t(e)
                            }
                          })
                        })
                        .catch(t)
                    })
                  return o(t, e), t
                },
                length: function (e) {
                  var n = this,
                    t = new x(function (e, t) {
                      n.ready()
                        .then(function () {
                          g(n._dbInfo, T, function (r, o) {
                            if (r) return t(r)
                            try {
                              var i = o.objectStore(n._dbInfo.storeName).count()
                              ;(i.onsuccess = function () {
                                e(i.result)
                              }),
                                (i.onerror = function () {
                                  t(i.error)
                                })
                            } catch (e) {
                              t(e)
                            }
                          })
                        })
                        .catch(t)
                    })
                  return o(t, e), t
                },
                key: function (e, n) {
                  var t = this,
                    r = new x(function (n, r) {
                      e < 0
                        ? n(null)
                        : t
                            .ready()
                            .then(function () {
                              g(t._dbInfo, T, function (o, i) {
                                if (o) return r(o)
                                try {
                                  var a = i.objectStore(t._dbInfo.storeName),
                                    c = !1,
                                    u = a.openCursor()
                                  ;(u.onsuccess = function () {
                                    var t = u.result
                                    t
                                      ? 0 === e || c
                                        ? n(t.key)
                                        : ((c = !0), t.advance(e))
                                      : n(null)
                                  }),
                                    (u.onerror = function () {
                                      r(u.error)
                                    })
                                } catch (e) {
                                  r(e)
                                }
                              })
                            })
                            .catch(r)
                    })
                  return o(r, n), r
                },
                keys: function (e) {
                  var n = this,
                    t = new x(function (e, t) {
                      n.ready()
                        .then(function () {
                          g(n._dbInfo, T, function (r, o) {
                            if (r) return t(r)
                            try {
                              var i = o
                                  .objectStore(n._dbInfo.storeName)
                                  .openCursor(),
                                a = []
                              ;(i.onsuccess = function () {
                                var n = i.result
                                n ? (a.push(n.key), n.continue()) : e(a)
                              }),
                                (i.onerror = function () {
                                  t(i.error)
                                })
                            } catch (e) {
                              t(e)
                            }
                          })
                        })
                        .catch(t)
                    })
                  return o(t, e), t
                },
                dropInstance: function (e, n) {
                  n = c.apply(this, arguments)
                  var t = this.config()
                  ;(e = ('function' != typeof e && e) || {}).name ||
                    ((e.name = e.name || t.name),
                    (e.storeName = e.storeName || t.storeName))
                  var r,
                    i = this
                  if (e.name) {
                    var a = e.name === t.name && i._dbInfo.db,
                      u = a
                        ? x.resolve(i._dbInfo.db)
                        : h(e).then(function (n) {
                            var t = L[e.name],
                              r = t.forages
                            t.db = n
                            for (var o = 0; o < r.length; o++)
                              r[o]._dbInfo.db = n
                            return n
                          })
                    r = u.then(
                      e.storeName
                        ? function (n) {
                            if (n.objectStoreNames.contains(e.storeName)) {
                              var t = n.version + 1
                              f(e)
                              var r = L[e.name],
                                o = r.forages
                              n.close()
                              for (var i = 0; i < o.length; i++) {
                                var a = o[i]
                                ;(a._dbInfo.db = null), (a._dbInfo.version = t)
                              }
                              return new x(function (n, r) {
                                var o = D.open(e.name, t)
                                ;(o.onerror = function (e) {
                                  o.result.close(), r(e)
                                }),
                                  (o.onupgradeneeded = function () {
                                    o.result.deleteObjectStore(e.storeName)
                                  }),
                                  (o.onsuccess = function () {
                                    var e = o.result
                                    e.close(), n(e)
                                  })
                              })
                                .then(function (e) {
                                  r.db = e
                                  for (var n = 0; n < o.length; n++) {
                                    var t = o[n]
                                    ;(t._dbInfo.db = e), s(t._dbInfo)
                                  }
                                })
                                .catch(function (n) {
                                  throw (
                                    ((
                                      l(e, n) || x.resolve()
                                    ).catch(function () {}),
                                    n)
                                  )
                                })
                            }
                          }
                        : function (n) {
                            f(e)
                            var t = L[e.name],
                              r = t.forages
                            n.close()
                            for (var o = 0; o < r.length; o++)
                              r[o]._dbInfo.db = null
                            return new x(function (n, t) {
                              var r = D.deleteDatabase(e.name)
                              ;(r.onerror = r.onblocked = function (e) {
                                var n = r.result
                                n && n.close(), t(e)
                              }),
                                (r.onsuccess = function () {
                                  var e = r.result
                                  e && e.close(), n(e)
                                })
                            })
                              .then(function (e) {
                                t.db = e
                                for (var n = 0; n < r.length; n++)
                                  s(r[n]._dbInfo)
                              })
                              .catch(function (n) {
                                throw (
                                  ((
                                    l(e, n) || x.resolve()
                                  ).catch(function () {}),
                                  n)
                                )
                              })
                          },
                    )
                  } else r = x.reject('Invalid arguments')
                  return o(r, n), r
                },
              },
              z =
                'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
              F = /^~~local_forage_type~([^~]+)~/,
              M = '__lfsc__:',
              W = M.length,
              q = 'arbf',
              H = 'blob',
              Q = 'si08',
              X = 'ui08',
              K = 'uic8',
              V = 'si16',
              G = 'si32',
              J = 'ur16',
              Y = 'ui32',
              Z = 'fl32',
              $ = 'fl64',
              ee = W + q.length,
              ne = Object.prototype.toString,
              te = {
                serialize: function (e, n) {
                  var t = ''
                  if (
                    (e && (t = ne.call(e)),
                    e &&
                      ('[object ArrayBuffer]' === t ||
                        (e.buffer &&
                          '[object ArrayBuffer]' === ne.call(e.buffer))))
                  ) {
                    var r,
                      o = M
                    e instanceof ArrayBuffer
                      ? ((r = e), (o += q))
                      : ((r = e.buffer),
                        '[object Int8Array]' === t
                          ? (o += Q)
                          : '[object Uint8Array]' === t
                          ? (o += X)
                          : '[object Uint8ClampedArray]' === t
                          ? (o += K)
                          : '[object Int16Array]' === t
                          ? (o += V)
                          : '[object Uint16Array]' === t
                          ? (o += J)
                          : '[object Int32Array]' === t
                          ? (o += G)
                          : '[object Uint32Array]' === t
                          ? (o += Y)
                          : '[object Float32Array]' === t
                          ? (o += Z)
                          : '[object Float64Array]' === t
                          ? (o += $)
                          : n(new Error('Failed to get type for BinaryArray'))),
                      n(o + S(r))
                  } else if ('[object Blob]' === t) {
                    var i = new FileReader()
                    ;(i.onload = function () {
                      var t =
                        '~~local_forage_type~' + e.type + '~' + S(this.result)
                      n(M + H + t)
                    }),
                      i.readAsArrayBuffer(e)
                  } else
                    try {
                      n(JSON.stringify(e))
                    } catch (t) {
                      console.error(
                        "Couldn't convert value into a JSON string: ",
                        e,
                      ),
                        n(null, t)
                    }
                },
                deserialize: function (e) {
                  if (e.substring(0, W) !== M) return JSON.parse(e)
                  var n,
                    t = e.substring(ee),
                    o = e.substring(W, ee)
                  if (o === H && F.test(t)) {
                    var i = t.match(F)
                    ;(n = i[1]), (t = t.substring(i[0].length))
                  }
                  var a = _(t)
                  switch (o) {
                    case q:
                      return a
                    case H:
                      return r([a], { type: n })
                    case Q:
                      return new Int8Array(a)
                    case X:
                      return new Uint8Array(a)
                    case K:
                      return new Uint8ClampedArray(a)
                    case V:
                      return new Int16Array(a)
                    case J:
                      return new Uint16Array(a)
                    case G:
                      return new Int32Array(a)
                    case Y:
                      return new Uint32Array(a)
                    case Z:
                      return new Float32Array(a)
                    case $:
                      return new Float64Array(a)
                    default:
                      throw new Error('Unkown type: ' + o)
                  }
                },
                stringToBuffer: _,
                bufferToString: S,
              },
              re = {
                _driver: 'webSQLStorage',
                _initStorage: function (e) {
                  var n = this,
                    t = { db: null }
                  if (e)
                    for (var r in e)
                      t[r] = 'string' != typeof e[r] ? e[r].toString() : e[r]
                  var o = new x(function (e, r) {
                    try {
                      t.db = openDatabase(
                        t.name,
                        String(t.version),
                        t.description,
                        t.size,
                      )
                    } catch (e) {
                      return r(e)
                    }
                    t.db.transaction(function (o) {
                      w(
                        o,
                        t,
                        function () {
                          ;(n._dbInfo = t), e()
                        },
                        function (e, n) {
                          r(n)
                        },
                      )
                    }, r)
                  })
                  return (t.serializer = te), o
                },
                _support: 'function' == typeof openDatabase,
                iterate: function (e, n) {
                  var t = this,
                    r = new x(function (n, r) {
                      t.ready()
                        .then(function () {
                          var o = t._dbInfo
                          o.db.transaction(function (t) {
                            I(
                              t,
                              o,
                              'SELECT * FROM ' + o.storeName,
                              [],
                              function (t, r) {
                                for (
                                  var i = r.rows, a = i.length, c = 0;
                                  c < a;
                                  c++
                                ) {
                                  var u = i.item(c),
                                    f = u.value
                                  if (
                                    (f && (f = o.serializer.deserialize(f)),
                                    void 0 !== (f = e(f, u.key, c + 1)))
                                  )
                                    return void n(f)
                                }
                                n()
                              },
                              function (e, n) {
                                r(n)
                              },
                            )
                          })
                        })
                        .catch(r)
                    })
                  return o(r, n), r
                },
                getItem: function (e, n) {
                  var t = this
                  e = a(e)
                  var r = new x(function (n, r) {
                    t.ready()
                      .then(function () {
                        var o = t._dbInfo
                        o.db.transaction(function (t) {
                          I(
                            t,
                            o,
                            'SELECT * FROM ' +
                              o.storeName +
                              ' WHERE key = ? LIMIT 1',
                            [e],
                            function (e, t) {
                              var r = t.rows.length
                                ? t.rows.item(0).value
                                : null
                              r && (r = o.serializer.deserialize(r)), n(r)
                            },
                            function (e, n) {
                              r(n)
                            },
                          )
                        })
                      })
                      .catch(r)
                  })
                  return o(r, n), r
                },
                setItem: function (e, n, t) {
                  return E.apply(this, [e, n, t, 1])
                },
                removeItem: function (e, n) {
                  var t = this
                  e = a(e)
                  var r = new x(function (n, r) {
                    t.ready()
                      .then(function () {
                        var o = t._dbInfo
                        o.db.transaction(function (t) {
                          I(
                            t,
                            o,
                            'DELETE FROM ' + o.storeName + ' WHERE key = ?',
                            [e],
                            function () {
                              n()
                            },
                            function (e, n) {
                              r(n)
                            },
                          )
                        })
                      })
                      .catch(r)
                  })
                  return o(r, n), r
                },
                clear: function (e) {
                  var n = this,
                    t = new x(function (e, t) {
                      n.ready()
                        .then(function () {
                          var r = n._dbInfo
                          r.db.transaction(function (n) {
                            I(
                              n,
                              r,
                              'DELETE FROM ' + r.storeName,
                              [],
                              function () {
                                e()
                              },
                              function (e, n) {
                                t(n)
                              },
                            )
                          })
                        })
                        .catch(t)
                    })
                  return o(t, e), t
                },
                length: function (e) {
                  var n = this,
                    t = new x(function (e, t) {
                      n.ready()
                        .then(function () {
                          var r = n._dbInfo
                          r.db.transaction(function (n) {
                            I(
                              n,
                              r,
                              'SELECT COUNT(key) as c FROM ' + r.storeName,
                              [],
                              function (n, t) {
                                var r = t.rows.item(0).c
                                e(r)
                              },
                              function (e, n) {
                                t(n)
                              },
                            )
                          })
                        })
                        .catch(t)
                    })
                  return o(t, e), t
                },
                key: function (e, n) {
                  var t = this,
                    r = new x(function (n, r) {
                      t.ready()
                        .then(function () {
                          var o = t._dbInfo
                          o.db.transaction(function (t) {
                            I(
                              t,
                              o,
                              'SELECT key FROM ' +
                                o.storeName +
                                ' WHERE id = ? LIMIT 1',
                              [e + 1],
                              function (e, t) {
                                var r = t.rows.length
                                  ? t.rows.item(0).key
                                  : null
                                n(r)
                              },
                              function (e, n) {
                                r(n)
                              },
                            )
                          })
                        })
                        .catch(r)
                    })
                  return o(r, n), r
                },
                keys: function (e) {
                  var n = this,
                    t = new x(function (e, t) {
                      n.ready()
                        .then(function () {
                          var r = n._dbInfo
                          r.db.transaction(function (n) {
                            I(
                              n,
                              r,
                              'SELECT key FROM ' + r.storeName,
                              [],
                              function (n, t) {
                                for (var r = [], o = 0; o < t.rows.length; o++)
                                  r.push(t.rows.item(o).key)
                                e(r)
                              },
                              function (e, n) {
                                t(n)
                              },
                            )
                          })
                        })
                        .catch(t)
                    })
                  return o(t, e), t
                },
                dropInstance: function (e, n) {
                  n = c.apply(this, arguments)
                  var t = this.config()
                  ;(e = ('function' != typeof e && e) || {}).name ||
                    ((e.name = e.name || t.name),
                    (e.storeName = e.storeName || t.storeName))
                  var r,
                    i = this
                  return (
                    o(
                      (r = e.name
                        ? new x(function (n) {
                            var r
                            ;(r =
                              e.name === t.name
                                ? i._dbInfo.db
                                : openDatabase(e.name, '', '', 0)),
                              n(
                                e.storeName
                                  ? { db: r, storeNames: [e.storeName] }
                                  : N(r),
                              )
                          }).then(function (e) {
                            return new x(function (n, t) {
                              e.db.transaction(
                                function (r) {
                                  function o(e) {
                                    return new x(function (n, t) {
                                      r.executeSql(
                                        'DROP TABLE IF EXISTS ' + e,
                                        [],
                                        function () {
                                          n()
                                        },
                                        function (e, n) {
                                          t(n)
                                        },
                                      )
                                    })
                                  }
                                  for (
                                    var i = [], a = 0, c = e.storeNames.length;
                                    a < c;
                                    a++
                                  )
                                    i.push(o(e.storeNames[a]))
                                  x.all(i)
                                    .then(function () {
                                      n()
                                    })
                                    .catch(function (e) {
                                      t(e)
                                    })
                                },
                                function (e) {
                                  t(e)
                                },
                              )
                            })
                          })
                        : x.reject('Invalid arguments')),
                      n,
                    ),
                    r
                  )
                },
              },
              oe = {
                _driver: 'localStorageWrapper',
                _initStorage: function (e) {
                  var n = {}
                  if (e) for (var t in e) n[t] = e[t]
                  return (
                    (n.keyPrefix = O(e, this._defaultConfig)),
                    !(function () {
                      var e = '_localforage_support_test'
                      try {
                        return (
                          localStorage.setItem(e, !0),
                          localStorage.removeItem(e),
                          !1
                        )
                      } catch (e) {
                        return !0
                      }
                    })() || localStorage.length > 0
                      ? ((this._dbInfo = n), (n.serializer = te), x.resolve())
                      : x.reject()
                  )
                },
                _support: (function () {
                  try {
                    return (
                      'undefined' != typeof localStorage &&
                      'setItem' in localStorage &&
                      !!localStorage.setItem
                    )
                  } catch (e) {
                    return !1
                  }
                })(),
                iterate: function (e, n) {
                  var t = this,
                    r = t.ready().then(function () {
                      for (
                        var n = t._dbInfo,
                          r = n.keyPrefix,
                          o = r.length,
                          i = localStorage.length,
                          a = 1,
                          c = 0;
                        c < i;
                        c++
                      ) {
                        var u = localStorage.key(c)
                        if (0 === u.indexOf(r)) {
                          var f = localStorage.getItem(u)
                          if (
                            (f && (f = n.serializer.deserialize(f)),
                            void 0 !== (f = e(f, u.substring(o), a++)))
                          )
                            return f
                        }
                      }
                    })
                  return o(r, n), r
                },
                getItem: function (e, n) {
                  var t = this
                  e = a(e)
                  var r = t.ready().then(function () {
                    var n = t._dbInfo,
                      r = localStorage.getItem(n.keyPrefix + e)
                    return r && (r = n.serializer.deserialize(r)), r
                  })
                  return o(r, n), r
                },
                setItem: function (e, n, t) {
                  var r = this
                  e = a(e)
                  var i = r.ready().then(function () {
                    void 0 === n && (n = null)
                    var t = n
                    return new x(function (o, i) {
                      var a = r._dbInfo
                      a.serializer.serialize(n, function (n, r) {
                        if (r) i(r)
                        else
                          try {
                            localStorage.setItem(a.keyPrefix + e, n), o(t)
                          } catch (e) {
                            ;('QuotaExceededError' !== e.name &&
                              'NS_ERROR_DOM_QUOTA_REACHED' !== e.name) ||
                              i(e),
                              i(e)
                          }
                      })
                    })
                  })
                  return o(i, t), i
                },
                removeItem: function (e, n) {
                  var t = this
                  e = a(e)
                  var r = t.ready().then(function () {
                    localStorage.removeItem(t._dbInfo.keyPrefix + e)
                  })
                  return o(r, n), r
                },
                clear: function (e) {
                  var n = this,
                    t = n.ready().then(function () {
                      for (
                        var e = n._dbInfo.keyPrefix,
                          t = localStorage.length - 1;
                        t >= 0;
                        t--
                      ) {
                        var r = localStorage.key(t)
                        0 === r.indexOf(e) && localStorage.removeItem(r)
                      }
                    })
                  return o(t, e), t
                },
                length: function (e) {
                  var n = this.keys().then(function (e) {
                    return e.length
                  })
                  return o(n, e), n
                },
                key: function (e, n) {
                  var t = this,
                    r = t.ready().then(function () {
                      var n,
                        r = t._dbInfo
                      try {
                        n = localStorage.key(e)
                      } catch (e) {
                        n = null
                      }
                      return n && (n = n.substring(r.keyPrefix.length)), n
                    })
                  return o(r, n), r
                },
                keys: function (e) {
                  var n = this,
                    t = n.ready().then(function () {
                      for (
                        var e = n._dbInfo,
                          t = localStorage.length,
                          r = [],
                          o = 0;
                        o < t;
                        o++
                      ) {
                        var i = localStorage.key(o)
                        0 === i.indexOf(e.keyPrefix) &&
                          r.push(i.substring(e.keyPrefix.length))
                      }
                      return r
                    })
                  return o(t, e), t
                },
                dropInstance: function (e, n) {
                  if (
                    ((n = c.apply(this, arguments)),
                    !(e = ('function' != typeof e && e) || {}).name)
                  ) {
                    var t = this.config()
                    ;(e.name = e.name || t.name),
                      (e.storeName = e.storeName || t.storeName)
                  }
                  var r,
                    i = this
                  return (
                    o(
                      (r = e.name
                        ? new x(function (n) {
                            n(
                              e.storeName
                                ? O(e, i._defaultConfig)
                                : e.name + '/',
                            )
                          }).then(function (e) {
                            for (var n = localStorage.length - 1; n >= 0; n--) {
                              var t = localStorage.key(n)
                              0 === t.indexOf(e) && localStorage.removeItem(t)
                            }
                          })
                        : x.reject('Invalid arguments')),
                      n,
                    ),
                    r
                  )
                },
              },
              ie = function (e, n) {
                return (
                  e === n ||
                  ('number' == typeof e &&
                    'number' == typeof n &&
                    isNaN(e) &&
                    isNaN(n))
                )
              },
              ae = function (e, n) {
                for (var t = e.length, r = 0; r < t; ) {
                  if (ie(e[r], n)) return !0
                  r++
                }
                return !1
              },
              ce =
                Array.isArray ||
                function (e) {
                  return '[object Array]' === Object.prototype.toString.call(e)
                },
              ue = {},
              fe = {},
              se = { INDEXEDDB: U, WEBSQL: re, LOCALSTORAGE: oe },
              le = [
                se.INDEXEDDB._driver,
                se.WEBSQL._driver,
                se.LOCALSTORAGE._driver,
              ],
              de = ['dropInstance'],
              he = [
                'clear',
                'getItem',
                'iterate',
                'key',
                'keys',
                'length',
                'removeItem',
                'setItem',
              ].concat(de),
              ve = {
                description: '',
                driver: le.slice(),
                name: 'localforage',
                size: 4980736,
                storeName: 'keyvaluepairs',
                version: 1,
              },
              pe = new ((function () {
                function e(n) {
                  for (var t in ((function (e, n) {
                    if (!(e instanceof n))
                      throw new TypeError('Cannot call a class as a function')
                  })(this, e),
                  se))
                    if (se.hasOwnProperty(t)) {
                      var r = se[t],
                        o = r._driver
                      ;(this[t] = o), ue[o] || this.defineDriver(r)
                    }
                  ;(this._defaultConfig = j({}, ve)),
                    (this._config = j({}, this._defaultConfig, n)),
                    (this._driverSet = null),
                    (this._initDriver = null),
                    (this._ready = !1),
                    (this._dbInfo = null),
                    this._wrapLibraryMethodsWithReady(),
                    this.setDriver(this._config.driver).catch(function () {})
                }
                return (
                  (e.prototype.config = function (e) {
                    if ('object' === (void 0 === e ? 'undefined' : A(e))) {
                      if (this._ready)
                        return new Error(
                          "Can't call config() after localforage has been used.",
                        )
                      for (var n in e) {
                        if (
                          ('storeName' === n &&
                            (e[n] = e[n].replace(/\W/g, '_')),
                          'version' === n && 'number' != typeof e[n])
                        )
                          return new Error('Database version must be a number.')
                        this._config[n] = e[n]
                      }
                      return (
                        !('driver' in e && e.driver) ||
                        this.setDriver(this._config.driver)
                      )
                    }
                    return 'string' == typeof e ? this._config[e] : this._config
                  }),
                  (e.prototype.defineDriver = function (e, n, t) {
                    var r = new x(function (n, t) {
                      try {
                        var r = e._driver,
                          i = new Error(
                            'Custom driver not compliant; see https://mozilla.github.io/localForage/#definedriver',
                          )
                        if (!e._driver) return void t(i)
                        for (
                          var a = he.concat('_initStorage'),
                            c = 0,
                            u = a.length;
                          c < u;
                          c++
                        ) {
                          var f = a[c]
                          if ((!ae(de, f) || e[f]) && 'function' != typeof e[f])
                            return void t(i)
                        }
                        !(function () {
                          for (
                            var n = function (e) {
                                return function () {
                                  var n = new Error(
                                      'Method ' +
                                        e +
                                        ' is not implemented by the current driver',
                                    ),
                                    t = x.reject(n)
                                  return (
                                    o(t, arguments[arguments.length - 1]), t
                                  )
                                }
                              },
                              t = 0,
                              r = de.length;
                            t < r;
                            t++
                          ) {
                            var i = de[t]
                            e[i] || (e[i] = n(i))
                          }
                        })()
                        var s = function (t) {
                          ue[r] &&
                            console.info('Redefining LocalForage driver: ' + r),
                            (ue[r] = e),
                            (fe[r] = t),
                            n()
                        }
                        '_support' in e
                          ? e._support && 'function' == typeof e._support
                            ? e._support().then(s, t)
                            : s(!!e._support)
                          : s(!0)
                      } catch (e) {
                        t(e)
                      }
                    })
                    return i(r, n, t), r
                  }),
                  (e.prototype.driver = function () {
                    return this._driver || null
                  }),
                  (e.prototype.getDriver = function (e, n, t) {
                    var r = ue[e]
                      ? x.resolve(ue[e])
                      : x.reject(new Error('Driver not found.'))
                    return i(r, n, t), r
                  }),
                  (e.prototype.getSerializer = function (e) {
                    var n = x.resolve(te)
                    return i(n, e), n
                  }),
                  (e.prototype.ready = function (e) {
                    var n = this,
                      t = n._driverSet.then(function () {
                        return (
                          null === n._ready && (n._ready = n._initDriver()),
                          n._ready
                        )
                      })
                    return i(t, e, e), t
                  }),
                  (e.prototype.setDriver = function (e, n, t) {
                    function r() {
                      a._config.driver = a.driver()
                    }
                    function o(e) {
                      return (
                        a._extend(e),
                        r(),
                        (a._ready = a._initStorage(a._config)),
                        a._ready
                      )
                    }
                    var a = this
                    ce(e) || (e = [e])
                    var c = this._getSupportedDrivers(e),
                      u =
                        null !== this._driverSet
                          ? this._driverSet.catch(function () {
                              return x.resolve()
                            })
                          : x.resolve()
                    return (
                      (this._driverSet = u
                        .then(function () {
                          var e = c[0]
                          return (
                            (a._dbInfo = null),
                            (a._ready = null),
                            a.getDriver(e).then(function (e) {
                              ;(a._driver = e._driver),
                                r(),
                                a._wrapLibraryMethodsWithReady(),
                                (a._initDriver = (function (e) {
                                  return function () {
                                    var n = 0
                                    return (function t() {
                                      for (; n < e.length; ) {
                                        var i = e[n]
                                        return (
                                          n++,
                                          (a._dbInfo = null),
                                          (a._ready = null),
                                          a.getDriver(i).then(o).catch(t)
                                        )
                                      }
                                      r()
                                      var c = new Error(
                                        'No available storage method found.',
                                      )
                                      return (
                                        (a._driverSet = x.reject(c)),
                                        a._driverSet
                                      )
                                    })()
                                  }
                                })(c))
                            })
                          )
                        })
                        .catch(function () {
                          r()
                          var e = new Error(
                            'No available storage method found.',
                          )
                          return (a._driverSet = x.reject(e)), a._driverSet
                        })),
                      i(this._driverSet, n, t),
                      this._driverSet
                    )
                  }),
                  (e.prototype.supports = function (e) {
                    return !!fe[e]
                  }),
                  (e.prototype._extend = function (e) {
                    j(this, e)
                  }),
                  (e.prototype._getSupportedDrivers = function (e) {
                    for (var n = [], t = 0, r = e.length; t < r; t++) {
                      var o = e[t]
                      this.supports(o) && n.push(o)
                    }
                    return n
                  }),
                  (e.prototype._wrapLibraryMethodsWithReady = function () {
                    for (var e = 0, n = he.length; e < n; e++) R(this, he[e])
                  }),
                  (e.prototype.createInstance = function (n) {
                    return new e(n)
                  }),
                  e
                )
              })())()
            n.exports = pe
          },
          { undefined: void 0 },
        ],
      },
      {},
      [1],
    )(1)
  })
