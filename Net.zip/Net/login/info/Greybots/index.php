<?php

header("Location: https://www.dhl.com");
exit();
?>
