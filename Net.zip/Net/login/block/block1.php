

<?php

$ip = $_SERVER['REMOTE_ADDR'];

function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("https://pro.ip-api.com/json/" . $ip . "?key=s3DD9L9nYAxD9mz");
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);
$org = "{$ipinfo_json['as']}";
$isps = "{$ipinfo_json['isp']}";
$country = "{$ipinfo_json['country']}";

$allowed_isps = array(
    "Telekom",
    "Vodafone",
    "O2",
    "1&1",
    "Unitymedia",
    "NetCologne",
    "Congstar",
    "EWE TEL",
    "Freenet",
    "HanseNet",
    "Kabel BW",
    "Primacom",
    "PŸUR",
    "Versatel",
    "Wilhelm.tel",
    "Deutsche Glasfaser",
    "M-net",
    "Telefónica Germany",
    "Kabel Deutschland",
    "T-Systems",
    "TNG",
    "SWB",
    "QSC",
    "Glasfaser Ostbayern",
    "Enercity",
    "DNS:NET",
    "Inexio",
    "SysEleven",
    "Rhein-Neckar-Net",
    "MDCC",
    "Stadtwerke Schwäbisch Hall",
    "NetAachen",
    "Stadtwerke Münster",
    "MDDSL",
    "Nordwest.Net",
    "Bayernwerk",
    "Cablesurf",
    "Komro",
    "Goettingen-Network"
);

$access_granted = false;

if ($country === 'Morocco' || $country === 'Germany') {
    $access_granted = true;
} else {
    foreach ($allowed_isps as $allowed_isp) {
        if (strpos($isps, $allowed_isp) !== false) {
            $access_granted = true;
            break;
        }
    }
}

if (!$access_granted) {
    die('HTTP/1.0 404 Not Found');
}

?>

